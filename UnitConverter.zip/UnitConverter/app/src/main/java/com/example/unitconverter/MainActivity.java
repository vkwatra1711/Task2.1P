package com.example.unitconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ImageButton imageButton1;
    ImageButton imageButton2;
    ImageButton imageButton3;
    TextView textView1;
    TextView textView2;
    TextView textView3;
    EditText editText;
    Spinner spinner;
    Float value;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spinner = findViewById(R.id.Spinner);
        editText = findViewById(R.id.input);
        textView1 = findViewById(R.id.textView1);
        textView2 = findViewById(R.id.textView2);
        textView3 = findViewById(R.id.textView3);
        imageButton1 = findViewById(R.id.imageButton1);
        imageButton2 = findViewById(R.id.imageButton2);
        imageButton3 = findViewById(R.id.imageButton3);

        imageButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(spinner.getSelectedItem().toString().equals("Meter"))
                {
                    value = Float.parseFloat(editText.getText().toString());
                    float value_1 = 100*value;
                    float value_2 = (float)((3.28084)*value);
                    float value_3 = (float)((39.3701)*value);

                    textView1.setText((String.format("%.2f",value_1))+" Centimeters");
                    textView2.setText((String.format("%.2f",value_2))+" Foot");
                    textView3.setText((String.format("%.2f",value_3))+" Inch");

                }
                else
                {
                    textView1.setText("");
                    textView2.setText("");
                    textView3.setText("");
                    Toast.makeText(MainActivity.this, "Select the right conversion",Toast.LENGTH_LONG).show();
                }
            }
        });
        imageButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(spinner.getSelectedItem().toString().equals("Celsius"))
                {
                    value = Float.parseFloat(editText.getText().toString());
                    float value_1 = (float)(((9*value)/5)+32);
                    float value_2 = (float)(value+273.151);

                    textView1.setText((String.format("%.2f",value_1))+" Fahrenheit");
                    textView2.setText((String.format("%.2f",value_2))+" Kelvin");

                }
                else
                {
                    textView1.setText("");
                    textView2.setText("");
                    textView3.setText("");
                    Toast.makeText(MainActivity.this, "Select the right conversion",Toast.LENGTH_LONG).show();
                }
            }
        });
        imageButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(spinner.getSelectedItem().toString().equals("Kilograms"))
                {
                    value = Float.parseFloat(editText.getText().toString());
                    float value_1 = 1000 * value;
                    float value_2 = (float) ((35.274)*value);
                    float value_3 = (float) ((2.205)*value);

                    textView1.setText((String.format("%.2f",value_1))+" Grams");
                    textView2.setText((String.format("%.2f",value_2))+" Ounces");
                    textView3.setText((String.format("%.2f",value_3))+" Pound");

                }
                else
                {
                    textView1.setText("");
                    textView2.setText("");
                    textView3.setText("");
                    Toast.makeText(MainActivity.this, "Select the right conversion",Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}